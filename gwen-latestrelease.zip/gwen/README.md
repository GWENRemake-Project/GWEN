# GWEN
This repository is where we put our latest builds!!!

tested with paper 1.11.2

# Setup

```txt
download the latest [release](http://link to latest release)
switch out your server jar with paper.jar
combine your server's plugin folder with gwen's plugin folder
start your server
```

> Note: paper.jar is 1.11.2, the recommended gwen version
> Note: If you are using Gwen release, paper.jar is not a plugin so do not put it in your plugins folder.
> Note: The plugins folder has essentials delete your servers essentials and use the essentials provided
> Note: The essentials plugins provided are not regular essentials, they are EssentialsX, a fork of essentials that works better.

GWEN ANIMATION:
The configs were generated from the plugins.
If you remove the configs it will autogenerate on next start but it wouldnt work with (or like) gwen.